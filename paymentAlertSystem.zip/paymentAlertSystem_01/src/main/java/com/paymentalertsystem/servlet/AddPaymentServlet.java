package com.paymentalertsystem.servlet;


import com.paymentalertsystem.dao.PaymentDAO;
import com.paymentalertsystem.model.Payment;

import java.io.IOException;
import java.sql.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class AddPaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession session = request.getSession();
            
            String userEmail = (String) session.getAttribute("email");
            Integer userId = (Integer) session.getAttribute("id"); // Get user_id from session

            System.out.println("User ID: " + userId + ", User Email: " + userEmail);

            if (userId == null) {
                response.sendRedirect("login.jsp?error=Session Expired");
                return;
            }

            String title = request.getParameter("title");
            String upi_id = request.getParameter("upi_id");
            double amount = Double.parseDouble(request.getParameter("amount"));
            Date dueDate = Date.valueOf(request.getParameter("due_date"));
            String category = request.getParameter("category");

            Payment payment = new Payment(title, upi_id, amount, dueDate, "Pending", userId);
            PaymentDAO paymentDAO = new PaymentDAO();

            boolean success = paymentDAO.addPayment(payment);

            if (success) {
                response.sendRedirect("dashboard.jsp?message=Payment Added Successfully");
                

                
            } else {
                response.sendRedirect("addpayment.jsp?error=Failed to Add Payment");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("addpayment.jsp?error=Invalid Data");
        } 
    }
}