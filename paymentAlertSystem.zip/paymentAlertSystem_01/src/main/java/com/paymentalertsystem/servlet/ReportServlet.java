package com.paymentalertsystem.servlet;

import com.paymentalertsystem.dao.ReportDAO;
import com.paymentalertsystem.model.Report;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

public class ReportServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("id");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        ReportDAO reportDAO = new ReportDAO();
        List<Report> reports = reportDAO.getMonthlyPayments(userId);

        request.setAttribute("reports", reports);
        request.getRequestDispatcher("report.jsp").forward(request, response);
    }
}
