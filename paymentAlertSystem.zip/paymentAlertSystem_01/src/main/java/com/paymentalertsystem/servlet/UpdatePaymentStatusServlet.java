package com.paymentalertsystem.servlet;

import com.paymentalertsystem.dao.DBConnection;
import com.paymentalertsystem.dao.DonePaymentDAO;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UpdatePaymentStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("id") == null) {
            response.sendRedirect("login.jsp?error=Please login first");
            return;
        }

        int paymentId = Integer.parseInt(request.getParameter("paymentId"));
        String status = request.getParameter("status");

        try  {
        	Connection conn = DBConnection.getConnection();
            PreparedStatement stmt = conn.prepareStatement("UPDATE Payment_Details SET status = ?, completed_date = NOW() WHERE id = ?");
            stmt.setString(1, status);
            stmt.setInt(2, paymentId);                 
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                if ("Done".equalsIgnoreCase(status)) {
                    DonePaymentDAO donePaymentDAO = new DonePaymentDAO();
                    donePaymentDAO.saveDonePayment(paymentId);
                }
                response.sendRedirect("dashboard.jsp?success=Payment updated successfully");
            } else {
                response.sendRedirect("dashboard.jsp?error=Payment update failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("dashboard.jsp?error=Database error");
        } 
    }
}