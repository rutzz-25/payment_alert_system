package com.paymentalertsystem.servlet;

import com.paymentalertsystem.dao.PaymentDAO;
import com.paymentalertsystem.model.Payment;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class PaymentHistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(false);
//        if (session == null || session.getAttribute("userId") == null) {
//            response.sendRedirect("login.jsp?error=Please login first");
//            return;
//        }

        int userId = (int) session.getAttribute("userId");
        PaymentDAO paymentDAO = new PaymentDAO();

        List<Payment> historyList = paymentDAO.getPaymentHistory(userId);
        request.setAttribute("historyList", historyList);
        request.getRequestDispatcher("paymenthistory.jsp").forward(request, response);
    }
}
