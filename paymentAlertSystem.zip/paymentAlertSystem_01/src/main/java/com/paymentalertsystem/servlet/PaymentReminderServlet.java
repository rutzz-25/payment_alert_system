//package com.paymentalertsystem.servlet;
//
//import java.io.IOException;
//import java.time.LocalDate;
//import java.time.temporal.ChronoUnit;
//import java.util.List;
//
//import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
//import javax.servlet.http.HttpServlet;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;
//
//import com.paymentalertsystem.dao.PaymentDAO;
//import com.paymentalertsystem.model.Payment;
//import com.paymentalertsystem.util.EmailUtil;
//
//@WebServlet("/PaymentReminderServlet")
//public class PaymentReminderServlet extends HttpServlet {
//    protected void doGet(HttpServletRequest request, HttpServletResponse response)
//            throws ServletException, IOException {
//        HttpSession session = request.getSession();
//        Integer userId = (Integer) session.getAttribute("userId");
//        
//        if (userId == null) {
//            response.sendRedirect("login.jsp");
//            return; // Redirect if user is not logged in
//        }
//
//        PaymentDAO paymentDAO = new PaymentDAO();
//        List<Payment> payments = paymentDAO.getPendingPayments(userId);
//
//        for (Payment payment : payments) {
//        	long daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), payment.getDueDate().toLocalDate());
//
//
//            
//            if (daysLeft == 2 || daysLeft == 1 || daysLeft == 0) {
//                String subject = "Payment Due Reminder";
//                String content = "Dear User,\n\n" +
//                        "Your payment is due soon:\n\n" +
//                        "🔔 Title: " + payment.getTitle() + "\n" +
//                        "💰 Amount: ₹" + payment.getAmount() + "\n" +
//                        "📅 Due Date: " + payment.getDueDate() + "\n\n" +
//                        "⏳ You have " + daysLeft + " day(s) left before the due date.\n\n" +
//                        "Thank you for using the Payment Alert System!";
//                
//             
//                System.out.println("Reminder sent for payment: " + payment.getTitle());
//            }
//        }
//    }
//}
