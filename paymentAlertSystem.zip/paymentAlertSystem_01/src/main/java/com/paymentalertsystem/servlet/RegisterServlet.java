package com.paymentalertsystem.servlet;

import com.paymentalertsystem.dao.UserDAO;
import com.paymentalertsystem.model.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User newUser = new User(0, name, email, password);
        UserDAO userDAO = new UserDAO();

        boolean userExists = userDAO.checkUserExists(email);
        if (userExists) {
            request.setAttribute("errorMessage", "Email already registered!");
            request.getRequestDispatcher("register.jsp").forward(request, response);
        } else {
            boolean isRegistered = userDAO.registerUser(newUser);
            if (isRegistered) {
                response.sendRedirect("login.jsp?message=Registration Successful! Please login.");
            } else {
                request.setAttribute("errorMessage", "Registration failed! Try again.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        }
    }
}
