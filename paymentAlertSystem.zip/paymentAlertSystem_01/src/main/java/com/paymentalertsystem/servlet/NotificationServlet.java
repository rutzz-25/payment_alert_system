package com.paymentalertsystem.servlet;

import com.paymentalertsystem.dao.DBConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

public class NotificationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	HttpSession session = request.getSession(false);
        
        // DEBUGGING: Print user ID to check if session exists
        System.out.println("User ID in session: " + session.getAttribute("id"));

        if (session == null || session.getAttribute("id") == null) {
            response.sendRedirect("login.jsp?error=Please login first");
            return;
        }

        int userId = (int) session.getAttribute("id");  // Make sure it's correctly retrieved

       
        List<String> notifications = new ArrayList<>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DBConnection.getConnection();
            String sql = "SELECT title, amount, due_date FROM Payment_Details " +
                         "WHERE user_id = ? " +
                         "AND due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 2 DAY) " +
                         "AND status = 'Pending'";

            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                java.sql.Date dueDate = rs.getDate("due_date");
                String alertType = dueDate.toLocalDate().equals(java.time.LocalDate.now().plusDays(1)) 
                                ? "🔔 Payment due tomorrow!" 
                                : "⚠️ Payment due soon!";

                String notification = rs.getString("title") + " - Rs." +
                                      rs.getDouble("amount") + " due on " + dueDate + " " + alertType;
                notifications.add(notification);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("notifications", notifications);
        request.getRequestDispatcher("notification.jsp").forward(request, response);
    }
}
