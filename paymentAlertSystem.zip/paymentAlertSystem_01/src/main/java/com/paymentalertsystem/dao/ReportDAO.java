package com.paymentalertsystem.dao;

import com.paymentalertsystem.model.Report;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

	public List<Report> getMonthlyPayments(int userId) {
	    List<Report> reports = new ArrayList<>();

	    try (
	        Connection conn = DBConnection.getConnection();
	        PreparedStatement stmt = conn.prepareStatement(
	        		"SELECT DATE_FORMAT(completed_date, '%M %Y') AS month, SUM(amount) AS totalAmount\n"
	        		+ "	     FROM Payment_Details WHERE status = 'Done' AND user_id = ?\n"
	        		+ "         GROUP BY DATE_FORMAT(completed_date, '%Y-%m')\n"
	        		+ "		 ORDER BY MAX(completed_date) DESC;"
	        		+ "");
	        )
	     {
	        stmt.setInt(1, userId);
	        ResultSet rs = stmt.executeQuery();

	        while (rs.next()) {
	            reports.add(new Report(rs.getString("month"), rs.getDouble("totalAmount")));
	        }

	        rs.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return reports;
	}

}
