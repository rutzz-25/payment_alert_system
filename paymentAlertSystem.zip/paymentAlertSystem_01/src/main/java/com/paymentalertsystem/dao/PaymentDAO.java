package com.paymentalertsystem.dao;

import com.paymentalertsystem.model.Payment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {

	public boolean addPayment(Payment payment) {
	    try {
	        Connection conn = DBConnection.getConnection();
	        PreparedStatement ps = conn.prepareStatement(
	        	    "INSERT INTO Payment_Details (user_id, title, amount, due_date, status, upi_id) VALUES (?, ?, ?, ?, ?, ?)"
	        	);


	        ps.setInt(1, payment.getUserId());
	        ps.setString(2, payment.getTitle());
	        ps.setDouble(3, payment.getAmount());
	        ps.setDate(4, new java.sql.Date(payment.getDueDate().getTime()));
	        ps.setString(5, payment.getStatus() != null ? payment.getStatus() : "Pending");
	        ps.setString(6, payment.getUpi_id());

	        int rows = ps.executeUpdate();
	        return rows > 0;

	        
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}



	public List<Payment> getPendingPayments(int userId) {
	    List<Payment> payments = new ArrayList<>();
	    try (Connection conn = DBConnection.getConnection();
	         PreparedStatement stmt = conn.prepareStatement(
	                 "SELECT * FROM Payment_Details WHERE user_id = ? AND status = 'Pending'")) {

	        stmt.setInt(1, userId);
	        ResultSet rs = stmt.executeQuery();

	        while (rs.next()) {
	            Payment payment = new Payment(
	                    rs.getInt("id"),
	                    rs.getInt("user_id"),
	                    rs.getString("title"),
	                    rs.getString("upi_id"),
	                    rs.getDouble("amount"),
	                    rs.getDate("due_date"),
	                    rs.getString("status")
	            );
	            payments.add(payment); //  Add each payment to the list
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return payments; // Return the filled list
	}

    

    public boolean markPaymentAsDone(int paymentId) {
        try  {

        	Connection conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement("UPDATE Payment_Details SET status = 'Done' WHERE id = ?");
            ps.setInt(1, paymentId);
            int rowsUpdated = ps.executeUpdate();

            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

	public List<Payment> getPaymentHistory(Integer userId) {
		 List<Payment> paymentHistory = new ArrayList<>();
	       

	        try  {
	        	Connection conn = DBConnection.getConnection();
	             PreparedStatement stmt = conn.prepareStatement("SELECT id, user_id, title, amount, due_date, status, upi_id FROM Payment_Details WHERE user_id = ? AND status = 'Completed'");
	            stmt.setInt(1, userId);
	            ResultSet rs = stmt.executeQuery();

	            while (rs.next()) {
	                Payment payment = new Payment(
	                    rs.getInt("id"),
	                    rs.getInt("user_id"),
	                    rs.getString("title"),
	                    rs.getString("upi_id"),
	                    rs.getDouble("amount"),
	                    rs.getDate("due_date"),
	                    rs.getString("status") != null ? rs.getString("status") : "Pending"
	                );
	                paymentHistory.add(payment);
	                
	                rs.close();
	                stmt.close();
	                conn.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return paymentHistory;
	}
}
