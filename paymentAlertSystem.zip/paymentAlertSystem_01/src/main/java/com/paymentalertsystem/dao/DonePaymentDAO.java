package com.paymentalertsystem.dao;



import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DonePaymentDAO {

    public boolean saveDonePayment(int paymentId) {
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Done_Payment (payment_id, completed_date) VALUES (?, NOW())");
            ps.setInt(1, paymentId);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
} 