package com.paymentalertsystem.dao;

import com.paymentalertsystem.model.User;
import java.sql.*;

public class UserDAO {


    // Register a new user
    public boolean registerUser(User user) {
        boolean status = false;
        try  {
        	Connection con = DBConnection.getConnection();
        	PreparedStatement stmt = con.prepareStatement("INSERT INTO Users(name, email, password) VALUES (?, ?, ?)");
            stmt.setString(1, user.getName());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getPassword());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                status = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    // Validate user login
    public User validateUser(String email, String password) {
        User user = null;
      

        try {
        	Connection con = DBConnection.getConnection();
        	PreparedStatement stmt = con.prepareStatement ("SELECT * FROM Users WHERE email = ? AND password = ?");
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    // Get user by ID
    public User getUserById(int id) {
        User user = null;
      
        try {
        	Connection con = DBConnection.getConnection();
        	PreparedStatement stmt = con.prepareStatement( "SELECT * FROM Users WHERE id = ?");
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }

    // Update user profile
    public boolean updateUser(User user) {
        boolean status = false;
  

        try  {
        	Connection con = DBConnection.getConnection();
        	PreparedStatement stmt = con.prepareStatement( "UPDATE Users SET name=?, email=?, password=? WHERE id=?");
            stmt.setString(1, user.getName());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getPassword());
            stmt.setInt(4, user.getId());

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                status = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

    // Delete user account
    public boolean deleteUser(int id) {
        boolean status = false;
      
        try  {
        	Connection con = DBConnection.getConnection();
        	PreparedStatement stmt = con.prepareStatement( "DELETE FROM Users WHERE id=?");
            stmt.setInt(1, id);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                status = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return status;
    }

	public boolean checkUserExists(String email) {
		
		    boolean exists = false;
		   
		    
		    try  {
		    	Connection con = DBConnection.getConnection();
	        	PreparedStatement stmt = con.prepareStatement( "SELECT * FROM Users WHERE email = ?");
		        stmt.setString(1, email);
		        ResultSet rs = stmt.executeQuery();
		        
		        if (rs.next()) {
		            exists = true; // Email already exists
		        }
		        
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		    
		    return exists;
		}

	}