package com.paymentalertsystem.model;

import java.sql.Date; // Use SQL date

public class Payment {
    private int id;
    private int userId;
    private String title;
    private String upiId;
    private double amount;
    private Date dueDate;
    private String status;
    private String userEmail;
    

    public Payment(String title, String upiId, double amount, Date dueDate, String status, int userId) {
        this.title = title;
        this.upiId = upiId;
        this.amount = amount;
        this.dueDate = dueDate;
        this.status = status;
        this.userId = userId;
    }


    public Payment(int id, int userId, String title, String upiId, double amount, Date dueDate, String status) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.upiId = upiId;
        this.amount = amount;
        this.dueDate = dueDate;
        this.status = status;
    }
    

	public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getUpi_id() { return upiId; }
    public void setUpi_id(String upi_id) { this.upiId = upi_id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

	public String getPaymentMethod() {
		// TODO Auto-generated method stub
		return null;
	}


    public String getUserEmail() {
    return userEmail;
    } 

    public void setUserEmail(String userEmail) {
    this.userEmail = userEmail;
    }
}
