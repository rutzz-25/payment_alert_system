package com.paymentalertsystem.model;

public class Report {
    private int id;
    private int userId;
    private double totalAmount;
    private int totalTransactions;
	private String month;

    public Report(String string, double d) { 
    
    this.month = string;
    this.totalAmount= d;
   
    }

    public Report(int id, int userId, double totalAmount, int totalTransactions) {
        this.id = id;
        this.userId = userId;
        this.totalAmount = totalAmount;
        this.totalTransactions = totalTransactions;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }

    public int getTotalTransactions() { return totalTransactions; }
    public void setTotalTransactions(int totalTransactions) { this.totalTransactions = totalTransactions; }
    
    public String getMonth() { return month; }
    public void setMonth(String month) { this.month = month; }
} 