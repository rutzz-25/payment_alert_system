package com.paymentalertsystem.model;

import java.util.Date;

public class Addpayment {
    private int id;
    private int userId;
    private String title;
    private double amount;
    private Date dueDate;
    private String status;

    public Addpayment() {}

    public void AddPayment(int id, int userId, String title, double amount, Date dueDate, String status) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.amount = amount;
        this.dueDate = dueDate;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
