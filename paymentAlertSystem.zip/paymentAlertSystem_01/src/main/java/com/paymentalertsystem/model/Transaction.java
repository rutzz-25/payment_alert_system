package com.paymentalertsystem.model;

import java.util.Date;

public class Transaction {
    private int id;
    private int userId;
    private int paymentId;
    private double amount;
    private Date transactionDate;
    private String status;

    public Transaction() {}

    public Transaction(int id, int userId, int paymentId, double amount, Date transactionDate, String status) {
        this.id = id;
        this.userId = userId;
        this.paymentId = paymentId;
        this.amount = amount;
        this.transactionDate = transactionDate;
        this.status = status;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getPaymentId() { return paymentId; }
    public void setPaymentId(int paymentId) { this.paymentId = paymentId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getTransactionDate() { return transactionDate; }
    public void setTransactionDate(Date transactionDate) { this.transactionDate = transactionDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
