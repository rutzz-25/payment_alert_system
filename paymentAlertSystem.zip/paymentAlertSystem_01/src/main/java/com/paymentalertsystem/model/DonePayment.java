package com.paymentalertsystem.model;

import java.util.Date;

public class DonePayment {
    private int id;
    private int userId;
    private int paymentId;
    private double amount;
    private Date completionDate;

    public DonePayment() {}

    public DonePayment(int id, int userId, int paymentId, double amount, Date completionDate) {
        this.id = id;
        this.userId = userId;
        this.paymentId = paymentId;
        this.amount = amount;
        this.completionDate = completionDate;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public int getPaymentId() { return paymentId; }
    public void setPaymentId(int paymentId) { this.paymentId = paymentId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Date getCompletionDate() { return completionDate; }
    public void setCompletionDate(Date completionDate) { this.completionDate = completionDate; }
}
