package com.paymentalertsystem.model;

import java.util.Date;

public class Alert {
    private int id;
    private int userId;
    private String message;
    private Date alertDate;

    public Alert() {}

    public Alert(int id, int userId, String message, Date alertDate) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.alertDate = alertDate;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Date getAlertDate() { return alertDate; }
    public void setAlertDate(Date alertDate) { this.alertDate = alertDate; }
}
